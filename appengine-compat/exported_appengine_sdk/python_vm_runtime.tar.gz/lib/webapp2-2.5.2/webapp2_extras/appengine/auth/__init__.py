# -*- coding: utf-8 -*-
"""
    webapp2_extras.appengine.auth
    =============================

    Authentication and authorization utilities.

    :copyright: 2011 by tipfy.org.
    :license: Apache Sotware License, see LICENSE for details.
"""
